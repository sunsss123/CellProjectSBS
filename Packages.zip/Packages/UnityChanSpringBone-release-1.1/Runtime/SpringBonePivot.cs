﻿using UnityEngine;

namespace Unity.Animations.SpringBones
{
    public class SpringBonePivot : MonoBehaviour
    {
    }
}