# Changelog
All notable changes to this package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2019-10-31
*This is the first version of UnityChan Spring Bone in the package form.*

### Changed
- Directory Structure changed in package form.

### Fixed

## [1.0.0] - 2018-05-09
- Initinal Release
